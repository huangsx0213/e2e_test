import React, { useState, useEffect } from "react";
import { Plus, Trash2, Save, Search, Globe, Check, X, RefreshCw } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { MutationActions } from "@/shared/hooks/useQueryHooks";
import { queryKeys } from "@/shared/hooks/queryKeys";
import { ApiEndpoint } from "@/shared/types";
import { HelpTooltip } from "@/shared/ui/HelpTooltip";
import { ConfirmModal } from "@/shared/ui/ConfirmModal";

interface EndpointManagerProps {
  endpoints: ApiEndpoint[];
  endpointsApi: MutationActions<ApiEndpoint>;
  environments: string[];
  currentProjectId: string;
}

export const EndpointManager: React.FC<EndpointManagerProps> = ({
  endpoints,
  endpointsApi,
  environments,
  currentProjectId,
}) => {
  const queryClient = useQueryClient();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Editing state
  const [editName, setEditName] = useState("");
  const [editDesc, setEditDesc] = useState("");
  const [editUrls, setEditUrls] = useState<Record<string, string>>({});
  const [editParams, setEditParams] = useState<
    { key: string; value: string; enabled: boolean }[]
  >([]);
  const [deleteConfirm, setDeleteConfirm] = useState<{
    type: "endpoint" | "param";
    id: string | number;
  } | null>(null);
  const [saveStatus, setSaveStatus] = useState<
    "idle" | "saving" | "success" | "error"
  >("idle");

  const selectedEndpoint = endpoints.find((e) => e.id === selectedId);

  useEffect(() => {
    if (selectedId && !endpoints.find((e) => e.id === selectedId)) {
      setSelectedId(null);
    }
  }, [endpoints, selectedId]);

  const handleSelect = (endpoint: ApiEndpoint) => {
    setSelectedId(endpoint.id);
    setEditName(endpoint.name);
    setEditDesc(endpoint.description || "");
    setEditUrls({ ...endpoint.baseUrls });
    setEditParams(endpoint.parameters ? [...endpoint.parameters] : []);
    setSaveStatus("idle");
  };

  const handleCreate = async () => {
    if (!currentProjectId) return;
    const initialUrls: Record<string, string> = {};
    environments.forEach((env) => (initialUrls[env] = ""));

    const newEndpoint: ApiEndpoint = {
      id: `e_${Date.now()}`,
      projectId: currentProjectId,
      name: "New Service Endpoint",
      description: "",
      baseUrls: initialUrls,
      parameters: [],
    };
    await endpointsApi.create(newEndpoint);
    handleSelect(newEndpoint);
  };

  const handleSave = async () => {
    if (!selectedId) return;
    setSaveStatus("saving");
    try {
      await endpointsApi.update(selectedId, {
        name: editName,
        description: editDesc,
        baseUrls: editUrls,
        parameters: editParams,
      });
      setSaveStatus("success");
      setTimeout(() => setSaveStatus("idle"), 3000);
    } catch (error) {
      setSaveStatus("error");
      setTimeout(() => setSaveStatus("idle"), 3000);
    }
  };

  const handleDelete = async (id: string) => {
    await endpointsApi.remove(id);
    if (selectedId === id) setSelectedId(null);
  };

  const filteredEndpoints = endpoints.filter((e) =>
    e.name.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  return (
    <div className="flex h-full bg-white relative">
      <ConfirmModal
        isOpen={!!deleteConfirm}
        title={
          deleteConfirm?.type === "endpoint"
            ? "Delete Endpoint"
            : "Remove Parameter"
        }
        message={
          deleteConfirm?.type === "endpoint"
            ? "Are you sure you want to delete this endpoint? This action cannot be undone."
            : "Are you sure you want to remove this parameter?"
        }
        onConfirm={() => {
          if (deleteConfirm?.type === "endpoint") {
            handleDelete(deleteConfirm.id as string);
          } else if (deleteConfirm?.type === "param") {
            const newParams = [...editParams];
            newParams.splice(deleteConfirm.id as number, 1);
            setEditParams(newParams);
          }
          setDeleteConfirm(null);
        }}
        onClose={() => setDeleteConfirm(null)}
      />
      {/* Sidebar List */}
    <div className="w-80 border-r border-gray-200 flex flex-col bg-gray-50">
      <div className="p-4 border-b border-gray-200 bg-white space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center">
            Endpoints
            <HelpTooltip content="Manage API endpoints and their base URLs across different environments." />
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                setIsRefreshing(true);
                queryClient.invalidateQueries({ queryKey: queryKeys.endpoints });
                setTimeout(() => setIsRefreshing(false), 500);
              }}
              className="text-gray-400 hover:text-blue-600 p-1 rounded-md hover:bg-blue-50 transition-colors"
              title="Refresh"
            >
              <RefreshCw size={14} className={isRefreshing ? "animate-spin" : ""} />
            </button>
            <button
              onClick={handleCreate}
              className="text-gray-400 hover:text-blue-600 p-1 rounded-md hover:bg-blue-50 transition-colors"
              title="Create New Endpoint"
            >
              <Plus size={14} />
            </button>
          </div>
        </div>
        <div className="relative">
          <Search
            className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400"
            size={14}
          />
          <input
            type="text"
            placeholder="Search endpoints..."
            className="w-full pl-8 pr-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filteredEndpoints.map((endpoint) => (
            <div
              key={endpoint.id}
              onClick={() => handleSelect(endpoint)}
              className={`p-3 rounded-lg cursor-pointer border transition-all group ${
                selectedId === endpoint.id
                  ? "bg-white border-blue-200 shadow-sm ring-1 ring-blue-500/20"
                  : "bg-transparent border-transparent hover:bg-white hover:border-gray-200"
              }`}
            >
              <div className="flex justify-between items-start mb-1">
                <span
                  className={`font-medium text-sm ${selectedId === endpoint.id ? "text-blue-700" : "text-gray-700"}`}
                >
                  {endpoint.name}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setDeleteConfirm({ type: "endpoint", id: endpoint.id });
                  }}
                  className="text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 size={14} />
                </button>
              </div>
              <p className="text-xs text-gray-500 truncate">
                {endpoint.description || "No description"}
              </p>
            </div>
          ))}
          {filteredEndpoints.length === 0 && (
            <div className="text-center py-8 text-gray-400 text-xs">
              No endpoints found.
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 bg-white">
        {selectedEndpoint ? (
          <>
            {/* Header */}
            <div className="h-16 border-b border-gray-200 flex items-center justify-between px-8 bg-white shrink-0">
              <div>
                <h1 className="text-lg font-bold text-gray-900">
                  {editName || "Untitled Endpoint"}
                </h1>
                <p className="text-xs text-gray-500 font-mono">
                  ID: {selectedEndpoint.id}
                </p>
              </div>
              <div className="flex items-center gap-4">
                {saveStatus === "saving" && (
                  <span className="text-xs text-gray-500 animate-pulse">
                    Saving...
                  </span>
                )}
                {saveStatus === "success" && (
                  <span className="text-xs text-green-600 font-medium flex items-center gap-1">
                    <Check size={14} /> Saved successfully
                  </span>
                )}
                {saveStatus === "error" && (
                  <span className="text-xs text-red-600 font-medium flex items-center gap-1">
                    <X size={14} /> Save failed
                  </span>
                )}
                <button
                  onClick={handleSave}
                  disabled={saveStatus === "saving"}
                  className={`flex items-center gap-2 px-4 py-2 text-white text-sm font-medium rounded-md transition-colors shadow-sm ${
                    saveStatus === "saving"
                      ? "bg-blue-400 cursor-not-allowed"
                      : "bg-blue-600 hover:bg-blue-700"
                  }`}
                >
                  <Save size={16} />
                  Save
                </button>
              </div>
            </div>

            {/* Editor */}
            <div className="flex-1 overflow-y-auto p-8">
              <div className="w-full space-y-8">
                {/* Basic Info */}
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wide border-b border-gray-100 pb-2">
                    General Information
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Name
                      </label>
                      <input
                        className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        placeholder="e.g. User Service"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                      </label>
                      <input
                        className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                        value={editDesc}
                        onChange={(e) => setEditDesc(e.target.value)}
                        placeholder="Describe this service..."
                      />
                    </div>
                  </div>
                </div>

                {/* Environment URLs */}
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wide border-b border-gray-100 pb-2 flex items-center gap-2">
                    Environment URLs
                  </h3>
                  <p className="text-xs text-gray-500 mb-2">
                    Define the base URL for each environment. You can use{" "}
                    <code className="bg-gray-100 px-1 rounded">
                      {"{{variable}}"}
                    </code>{" "}
                    or{" "}
                    <code className="bg-gray-100 px-1 rounded">
                      {"{variable}"}
                    </code>{" "}
                    syntax for dynamic path segments (e.g.,{" "}
                    <code className="bg-gray-100 px-1 rounded">
                      https://api.example.com/{"{version}"}
                    </code>
                    ).
                  </p>
                  <div className="bg-gray-50 rounded-lg border border-gray-200 p-4 space-y-4">
                    {Array.from(new Set([...environments, ...Object.keys(editUrls)])).sort().map((env) => (
                      <div
                        key={env}
                        className="grid grid-cols-12 gap-4 items-center"
                      >
                        <div className="col-span-2">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border ${
                              env === "PROD"
                                ? "bg-red-50 text-red-700 border-red-200"
                                : env === "UAT"
                                  ? "bg-teal-50 text-teal-700 border-teal-200"
                                  : env === "SIT"
                                    ? "bg-blue-50 text-blue-700 border-blue-200"
                                    : env === "DEV"
                                      ? "bg-green-50 text-green-700 border-green-200"
                                      : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {env}
                          </span>
                        </div>
                        <div className="col-span-10">
                          <input
                            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md text-sm font-mono text-gray-600 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none placeholder-gray-300"
                            value={editUrls[env] || ""}
                            onChange={(e) =>
                              setEditUrls({
                                ...editUrls,
                                [env]: e.target.value,
                              })
                            }
                            placeholder={env === 'default' ? "Recorded Base URL" : `https://${env.toLowerCase()}-api.example.com`}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500">
                    Define the base URL for each environment. These will be used
                    when executing tests against a specific environment.
                  </p>
                </div>

                {/* URL Parameters */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                    <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wide flex items-center gap-2">
                      URL Parameters
                    </h3>
                    <button
                      onClick={() =>
                        setEditParams([
                          ...editParams,
                          { key: "", value: "", enabled: true },
                        ])
                      }
                      className="text-xs font-medium text-blue-600 hover:text-blue-700 flex items-center gap-1"
                    >
                      <Plus size={14} /> Add Parameter
                    </button>
                  </div>

                  <div className="bg-gray-50 rounded-lg border border-gray-200 overflow-hidden">
                    {editParams.length === 0 ? (
                      <div className="p-8 text-center text-gray-400 text-sm">
                        No URL parameters defined.
                      </div>
                    ) : (
                      <div className="divide-y divide-gray-200">
                        {editParams.map((param, index) => (
                          <div
                            key={index}
                            className="flex items-center gap-3 p-3 bg-white hover:bg-gray-50 transition-colors"
                          >
                            <button
                              onClick={() => {
                                const newParams = [...editParams];
                                newParams[index].enabled =
                                  !newParams[index].enabled;
                                setEditParams(newParams);
                              }}
                              className={`p-1 rounded-md transition-colors shrink-0 ${param.enabled ? "text-blue-600 hover:bg-blue-50" : "text-gray-400 hover:bg-gray-100"}`}
                            >
                              {param.enabled ? (
                                <Check size={16} />
                              ) : (
                                <X size={16} />
                              )}
                            </button>
                            <input
                              className={`flex-1 px-3 py-1.5 border border-gray-300 rounded-md text-sm font-mono focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none ${!param.enabled && "opacity-50"}`}
                              placeholder="Key"
                              value={param.key}
                              onChange={(e) => {
                                const newParams = [...editParams];
                                newParams[index].key = e.target.value;
                                setEditParams(newParams);
                              }}
                            />
                            <span className="text-gray-400 font-mono">=</span>
                            <input
                              className={`flex-[2] px-3 py-1.5 border border-gray-300 rounded-md text-sm font-mono focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none ${!param.enabled && "opacity-50"}`}
                              placeholder="Value (can use {{variables}})"
                              value={param.value}
                              onChange={(e) => {
                                const newParams = [...editParams];
                                newParams[index].value = e.target.value;
                                setEditParams(newParams);
                              }}
                            />
                            <button
                              onClick={() => {
                                setDeleteConfirm({ type: "param", id: index });
                              }}
                              className="p-1.5 text-gray-400 hover:text-red-500 rounded-md hover:bg-red-50 transition-colors shrink-0"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-gray-500">
                    These parameters will be appended to the URL as query string
                    (e.g., ?key=value). You can use {"{{variable}}"} or{" "}
                    {"{variable}"} syntax for dynamic values.
                  </p>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-gray-400 bg-gray-50/30">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <Globe size={32} className="text-gray-300" />
            </div>
            <p className="text-sm font-medium">Select an endpoint to edit</p>
          </div>
        )}
      </div>
    </div>
  );
}
