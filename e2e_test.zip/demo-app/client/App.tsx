import React from 'react';
import { Routes, Route, Link, Outlet, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, FormInput, Settings } from 'lucide-react';
import { Dashboard } from './Dashboard';
import { UserManagement } from './UserManagement';
import { AdvancedForm } from './AdvancedForm';

function Layout() {
  const location = useLocation();
  const navItems = [
    { path: '/demo', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { path: '/demo/users', label: 'User Management', icon: <Users size={20} /> },
    { path: '/demo/form', label: 'Advanced Form', icon: <FormInput size={20} /> },
  ];

  return (
    <div className="flex h-screen bg-gray-50 text-slate-800 font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 flex flex-col text-white">
        <div className="h-16 flex items-center px-6 border-b border-slate-700">
          <h1 className="text-xl font-bold text-blue-400">Target App Demo</h1>
        </div>
        <nav className="flex-1 py-6 px-3 space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path || (item.path !== '/demo' && location.pathname.startsWith(item.path));
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                  isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {item.icon}
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-slate-700">
          <div className="flex items-center gap-3 px-3 py-2 text-slate-300">
            <Settings size={20} />
            <span className="text-sm">Settings v1.0.0</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto flex flex-col">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center px-8 shadow-sm">
          <h2 className="text-lg font-semibold text-gray-800">
            {navItems.find(i => location.pathname === i.path || (i.path !== '/demo' && location.pathname.startsWith(i.path)))?.label || 'Demo App'}
          </h2>
        </header>
        <div className="p-8 flex-1 overflow-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

export function App() {
  return (
    <Routes>
      <Route path="/demo" element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="users" element={<UserManagement />} />
        <Route path="form" element={<AdvancedForm />} />
      </Route>
    </Routes>
  );
}
