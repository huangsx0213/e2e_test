import React, { useEffect, useState } from 'react';
import { Users, UserIcon, Shield, Activity } from 'lucide-react';

export function Dashboard() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/demo-api/dashboard/stats')
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          setStats(res.data);
        }
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="text-center py-10" id="dashboard-loading">Loading dashboard...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6" id="dashboard-container">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between" id="stat-card-total-users">
          <div>
            <p className="text-sm font-medium text-gray-500">Total Users</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-1">{stats?.totalUsers || 0}</h3>
          </div>
          <div className="w-12 h-12 bg-blue-50 flex items-center justify-center rounded-lg text-blue-600">
            <Users size={24} />
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between" id="stat-card-active-users">
          <div>
            <p className="text-sm font-medium text-gray-500">Active Users</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-1">{stats?.activeUsers || 0}</h3>
          </div>
          <div className="w-12 h-12 bg-emerald-50 flex items-center justify-center rounded-lg text-emerald-600">
            <Activity size={24} />
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between" id="stat-card-admins">
          <div>
            <p className="text-sm font-medium text-gray-500">Administrators</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-1">{stats?.admins || 0}</h3>
          </div>
          <div className="w-12 h-12 bg-purple-50 flex items-center justify-center rounded-lg text-purple-600">
            <Shield size={24} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden" id="recent-registrations-card">
        <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50">
          <h3 className="font-semibold text-gray-800">Recent Registrations</h3>
        </div>
        <div className="divide-y divide-gray-100">
          {stats?.recentRegistrations.map((user: any) => (
            <div key={user.id} className="p-4 px-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-semibold text-sm">
                  {user.name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium text-gray-900">{user.name}</p>
                  <p className="text-sm text-gray-500">{user.email}</p>
                </div>
              </div>
              <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${
                user.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600'
              }`}>
                {user.status}
              </span>
            </div>
          ))}
          {(!stats?.recentRegistrations || stats.recentRegistrations.length === 0) && (
            <div className="p-6 text-center text-gray-500 text-sm">No recent users.</div>
          )}
        </div>
      </div>
    </div>
  );
}
