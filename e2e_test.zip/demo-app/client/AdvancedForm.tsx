import React, { useState } from 'react';

export function AdvancedForm() {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    priority: 5,
    date: '',
    time: '',
    isPrivate: false,
    tags: [] as string[],
    color: '#3b82f6',
    attachment: null as File | null
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const handleTagToggle = (tag: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.includes(tag) 
        ? prev.tags.filter(t => t !== tag)
        : [...prev.tags, tag]
    }));
  };

  return (
    <div className="max-w-3xl mx-auto" id="advanced-form-container">
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-100 bg-gray-50/50">
          <h2 className="text-lg font-semibold text-gray-800">Advanced Data Entry</h2>
          <p className="text-sm text-gray-500 mt-1">A form containing various control types for testing.</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6" id="complex-test-form">
          {submitted && (
            <div className="bg-emerald-50 text-emerald-700 p-4 rounded-lg text-sm border border-emerald-100 mb-6" id="success-alert">
              Form submitted successfully!
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1 md:col-span-2">
              <label htmlFor="input-title" className="block text-sm font-medium text-gray-700">Project Title (Text)</label>
              <input
                id="input-title"
                type="text"
                placeholder="Enter project title"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div className="space-y-1 md:col-span-2">
              <label htmlFor="textarea-desc" className="block text-sm font-medium text-gray-700">Description (Textarea)</label>
              <textarea
                id="textarea-desc"
                rows={4}
                placeholder="Detailed description..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="space-y-1">
              <label htmlFor="select-category" className="block text-sm font-medium text-gray-700">Category (Select)</label>
              <select
                id="select-category"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                value={formData.category}
                onChange={e => setFormData({ ...formData, category: e.target.value })}
              >
                <option value="">Select a category</option>
                <option value="development">Development</option>
                <option value="marketing">Marketing</option>
                <option value="design">Design</option>
              </select>
            </div>

            <div className="space-y-1 flex flex-col justify-center">
              <label htmlFor="range-priority" className="block text-sm font-medium text-gray-700">
                Priority: {formData.priority} (Range)
              </label>
              <input
                id="range-priority"
                type="range"
                min="1"
                max="10"
                className="w-full mt-2 accent-blue-600"
                value={formData.priority}
                onChange={e => setFormData({ ...formData, priority: parseInt(e.target.value) })}
              />
            </div>

            <div className="space-y-1">
              <label htmlFor="input-date" className="block text-sm font-medium text-gray-700">Deadline Date (Date)</label>
              <input
                id="input-date"
                type="date"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formData.date}
                onChange={e => setFormData({ ...formData, date: e.target.value })}
              />
            </div>

            <div className="space-y-1">
              <label htmlFor="input-time" className="block text-sm font-medium text-gray-700">Deadline Time (Time)</label>
              <input
                id="input-time"
                type="time"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formData.time}
                onChange={e => setFormData({ ...formData, time: e.target.value })}
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="block text-sm font-medium text-gray-700">Tags (Checkbox Group)</label>
              <div className="flex flex-wrap gap-4" id="checkbox-group-tags">
                {['frontend', 'backend', 'api', 'database'].map(tag => (
                  <label key={tag} className="flex items-center gap-2 text-sm cursor-pointer">
                    <input
                      type="checkbox"
                      id={`checkbox-tag-${tag}`}
                      checked={formData.tags.includes(tag)}
                      onChange={() => handleTagToggle(tag)}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    {tag.charAt(0).toUpperCase() + tag.slice(1)}
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label htmlFor="input-color" className="block text-sm font-medium text-gray-700">Theme Color (Color)</label>
              <div className="flex items-center gap-3">
                <input
                  id="input-color"
                  type="color"
                  className="h-10 w-14 p-1 border border-gray-300 rounded cursor-pointer"
                  value={formData.color}
                  onChange={e => setFormData({ ...formData, color: e.target.value })}
                />
                <span className="text-sm text-gray-500 font-mono">{formData.color}</span>
              </div>
            </div>

            <div className="space-y-1">
              <div className="block text-sm font-medium text-gray-700 mb-2">Privacy Setting (Toggle/Checkbox)</div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  id="toggle-private"
                  className="sr-only peer"
                  checked={formData.isPrivate}
                  onChange={e => setFormData({ ...formData, isPrivate: e.target.checked })}
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                <span className="ml-3 text-sm font-medium text-gray-700">{formData.isPrivate ? 'Private' : 'Public'}</span>
              </label>
            </div>

            <div className="space-y-1 md:col-span-2">
              <label htmlFor="input-file" className="block text-sm font-medium text-gray-700">Attachment (File)</label>
              <input
                id="input-file"
                type="file"
                className="w-full text-sm text-slate-500
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-lg file:border-0
                  file:text-sm file:font-semibold
                  file:bg-blue-50 file:text-blue-700
                  hover:file:bg-blue-100"
                onChange={e => {
                  if (e.target.files && e.target.files.length > 0) {
                    setFormData({ ...formData, attachment: e.target.files[0] });
                  }
                }}
              />
            </div>
          </div>

          <div className="pt-6 border-t border-gray-100 flex justify-end gap-3">
            <button
              type="button"
              id="reset-form-btn"
              onClick={() => setFormData({
                title: '', description: '', category: '', priority: 5, date: '', time: '', isPrivate: false, tags: [], color: '#3b82f6', attachment: null
              })}
              className="px-5 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Reset
            </button>
            <button
              type="submit"
              id="submit-form-btn"
              className="px-5 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
            >
              Submit Form
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
