import { Router } from 'express';

export const demoRouter = Router();

// In-memory mock database
const users = [
  { id: 1, name: 'Alice Smith', email: 'alice@example.com', role: 'admin', status: 'active', dob: '1990-05-15', notifications: true },
  { id: 2, name: 'Bob Jones', email: 'bob@example.com', role: 'editor', status: 'inactive', dob: '1985-08-22', notifications: false },
  { id: 3, name: 'Charlie Brown', email: 'charlie@example.com', role: 'viewer', status: 'active', dob: '1992-11-03', notifications: true }
];

let nextId = 4;

demoRouter.get('/users', (req, res) => {
  const { role, status, search } = req.query;
  let filteredUsers = [...users];

  if (role) {
    filteredUsers = filteredUsers.filter(u => u.role === role);
  }
  if (status) {
    filteredUsers = filteredUsers.filter(u => u.status === status);
  }
  if (search) {
    const s = String(search).toLowerCase();
    filteredUsers = filteredUsers.filter(u => u.name.toLowerCase().includes(s) || u.email.toLowerCase().includes(s));
  }

  res.json({ success: true, data: filteredUsers, total: filteredUsers.length });
});

demoRouter.get('/users/:id', (req, res) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }
  res.json({ success: true, data: user });
});

demoRouter.post('/users', (req, res) => {
  const { name, email, role, status, dob, notifications } = req.body;
  if (!name || !email) {
    return res.status(400).json({ success: false, error: 'Name and email are required' });
  }

  const newUser = {
    id: nextId++,
    name,
    email,
    role: role || 'viewer',
    status: status || 'inactive',
    dob: dob || null,
    notifications: !!notifications
  };

  users.push(newUser);
  res.status(201).json({ success: true, data: newUser });
});

demoRouter.put('/users/:id', (req, res) => {
  const index = users.findIndex(u => u.id === parseInt(req.params.id));
  if (index === -1) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }

  const { name, email, role, status, dob, notifications } = req.body;
  users[index] = {
    ...users[index],
    ...(name !== undefined && { name }),
    ...(email !== undefined && { email }),
    ...(role !== undefined && { role }),
    ...(status !== undefined && { status }),
    ...(dob !== undefined && { dob }),
    ...(notifications !== undefined && { notifications })
  };

  res.json({ success: true, data: users[index] });
});

demoRouter.delete('/users/:id', (req, res) => {
  const index = users.findIndex(u => u.id === parseInt(req.params.id));
  if (index === -1) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }

  const deletedUser = users.splice(index, 1)[0];
  res.json({ success: true, data: deletedUser });
});

demoRouter.get('/dashboard/stats', (req, res) => {
  res.json({
    success: true,
    data: {
      totalUsers: users.length,
      activeUsers: users.filter(u => u.status === 'active').length,
      admins: users.filter(u => u.role === 'admin').length,
      recentRegistrations: users.slice(-5)
    }
  });
});
